package com.Employee.config;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import com.Employee.Entity.EmployeesInfo;
import com.Employee.Repo.EmployeeRepository;
@Component
public class CustomUserDetailsService  implements UserDetailsService{
		private static final Logger LOGGER = LoggerFactory.getLogger(CustomUserDetailsService.class.getName());
	@Autowired
	 private EmployeeRepository employeeRepository;
	
	@Override
	public CustomUser loadUserByUsername(String email) {
		LOGGER.info("email:"+email);
	EmployeesInfo employee	=employeeRepository.findByEmail(email);
	CustomUser user =new CustomUser(employee);
	LOGGER.info("employee:"+employee);
	if(employee==null) {
		
		throw new UsernameNotFoundException("user name not found");
	}
	return user;
	
	}

}
