package com.Employee.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.firewall.DefaultHttpFirewall;
import org.springframework.security.web.firewall.HttpFirewall;
import org.springframework.security.web.firewall.HttpStatusRequestRejectedHandler;
import org.springframework.security.web.firewall.RequestRejectedHandler;
import org.springframework.security.web.firewall.StrictHttpFirewall;

import com.Employee.Service.EmployeeService;
import com.Employee.Service.EmployeeServiceimple;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Configuration
@EnableWebSecurity
public class SecurityConfig  {

	@Bean
    public BCryptPasswordEncoder passwordEncoders() {
          
            return new BCryptPasswordEncoder() ;
    }
    
	
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider daoAuthenticationProvider=new DaoAuthenticationProvider();
		daoAuthenticationProvider.setUserDetailsService(getDetailsService());
		daoAuthenticationProvider.setPasswordEncoder(passwordEncoders());
		return daoAuthenticationProvider;
	}
	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {
	    StrictHttpFirewall firewall = new StrictHttpFirewall();
	    firewall.setAllowBackSlash(true);
	    return (web) -> web.httpFirewall(firewall);
	}
	
	@Bean
	public  UserDetailsService getDetailsService() {
		
		return new CustomUserDetailsService();
	}
	
	

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
	     
	        http
	                .csrf(csrf ->csrf.disable())
	                .authorizeHttpRequests(authorize -> authorize
	                .requestMatchers("/user/**").authenticated()
	                .requestMatchers("/**").permitAll())
	                .formLogin(login -> login
	                .loginPage("/login")
	                .loginProcessingUrl("/employee/login")
	                .usernameParameter("email")
	                .passwordParameter("password")
	            	.defaultSuccessUrl("/user/home",true)
	            	.failureUrl("/login?error=true")	                
	                .permitAll())
	                .logout(logout -> logout
	                .logoutUrl("/logout")
	                .logoutSuccessUrl("/login")
	                .permitAll());

	        return http.build();
	    }

	@Bean
	public AuthenticationFailureHandler authenticationFailureHandler() {
	    return new SimpleUrlAuthenticationFailureHandler("/login?error");
	}
	
	@Bean
	RequestRejectedHandler requestRejectedHandler() {
	   return new HttpStatusRequestRejectedHandler();
	}
	
	@Bean
	public HttpFirewall allowSemicolonHttpFirewall() {
		StrictHttpFirewall firewall = new StrictHttpFirewall();
		firewall.setAllowSemicolon(true);
		return firewall;
	}
	
	
	} 
	
