package com.Employee.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "employees_info")
public class EmployeesInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column
    private String firstname;

    @Column
    private String lastname;

    @Column
    private String gender;

    @Column
    private String dob;

    @Column
    private String email;

    @Column
    private String password;

    @Column
    private String contact;

    @Column
    private String role;

    @ManyToOne
    @JoinColumn(name = "usertype")
    private Table_Usertype userType;

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Table_Usertype getUserType() {
        return userType;
    }

    public void setUserType(Table_Usertype userType) {
        this.userType = userType;
    }

   
	//public void get(int i) {
		// TODO Auto-generated method stub
		
	//}
    

}