package com.Employee.Service;


import java.util.List;

import com.Employee.Entity.EmployeesInfo;
import com.Employee.Entity.Table_Usertype;
import com.Employee.Model.EmployeeRegisterDto;
import com.Employee.Model.UsertypeRegisterDto;

	
public interface EmployeeService {

	void addEmployee(EmployeesInfo employee);

	EmployeesInfo getEmployeeById(int id);

	void updateEmployee(EmployeesInfo employeeInfo, int id);

	String employeeRegistration(EmployeeRegisterDto employeeRegisterDto, UsertypeRegisterDto usertypeDTO);

	List<EmployeesInfo> validateEmployee(String email, String password);

	void updateEmployee(EmployeesInfo employee);

	boolean isEmailUnique(String email);

	EmployeesInfo findByEmail(String email);

	EmployeesInfo getEmployeeByEmail(String email);

	List<EmployeesInfo> getAllEmployees();

	void deleteById(int id);

	int getUserTypeByUsername(String loggedInUsername);

	List<EmployeesInfo> findEmployeesByUserType(int userType);

	List<EmployeesInfo> getEmployeesByUserType(int userType);

	int getUserTypeById(String passingName);

	
	
	
	

	

	
	

	

	
	
	

	

	
	

	
	

	

	

	

	

	

	

	

	

	
	

	

	


		   

			
			
			}
		
	

	


