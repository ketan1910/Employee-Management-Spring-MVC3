
package com.Employee.Service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.Employee.Entity.EmployeesInfo;
import com.Employee.Entity.Table_Usertype;
import com.Employee.Model.EmployeeRegisterDto;
import com.Employee.Model.UsertypeRegisterDto;
import com.Employee.Repo.EmployeeRepository;
import com.Employee.Repo.UsertypeRepository;
import jakarta.transaction.Transactional;
@Service

public class EmployeeServiceimple implements EmployeeService {
    
	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeServiceimple.class.getName());
	
	@Autowired
	private EmployeeRepository employeeRepository;

   @Autowired
   private UsertypeRepository usertypeRepository;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncoders;
	
	@Autowired
    public void EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

	@Override
	public List<EmployeesInfo> getAllEmployees() {
		
		return employeeRepository.findAll();
	}
	@Override
	public EmployeesInfo getEmployeeById(int id) {
		
		return employeeRepository.findById(id);  
	}
	@Override
	public void addEmployee(EmployeesInfo employee) {
		String password=passwordEncoders.encode(employee.getPassword());
		employee.setPassword(password);
		employee.setRole("ROLE_USER");
		
		
		employeeRepository.save(employee);
	}
	
	
    @Override
	public void updateEmployee(EmployeesInfo employeeInfo,int id) {
	    EmployeesInfo existingEmployee = employeeRepository.findById(id);
        System.out.println("existingEmployee:"+existingEmployee);
		if (existingEmployee != null) {
        
        existingEmployee.setFirstname(employeeInfo.getFirstname());
        existingEmployee.setLastname(employeeInfo.getLastname());
        existingEmployee.setGender(employeeInfo.getGender());
        existingEmployee.setDob(employeeInfo.getDob());
        existingEmployee.setContact(employeeInfo.getContact());
        existingEmployee.setEmail(employeeInfo.getEmail());
        if(employeeInfo.getPassword() != null && !employeeInfo.getPassword().isEmpty()) {
            existingEmployee.setPassword(employeeInfo.getPassword());
            String password=passwordEncoders.encode(employeeInfo.getPassword());
            existingEmployee.setPassword(password);
           }
       
        System.out.println("existingEmployee after change:"+existingEmployee);
        employeeRepository.save(existingEmployee);
    }
}
	@Override
	public String employeeRegistration(EmployeeRegisterDto employeeRegisterDto, UsertypeRegisterDto usertypeDTO) {

	    EmployeesInfo employee = new EmployeesInfo();

	    employee.setFirstname(employeeRegisterDto.getFirstName());
	    employee.setLastname(employeeRegisterDto.getLastName());
	    employee.setGender(employeeRegisterDto.getGender());
	    employee.setDob(employeeRegisterDto.getDob());
	    employee.setContact(employeeRegisterDto.getContact());
	    employee.setEmail(employeeRegisterDto.getEmail());
	    employee.setPassword(employeeRegisterDto.getPassword());
	    String password = passwordEncoders.encode(employee.getPassword());
	    employee.setPassword(password);
	    employee.setRole("ROLE_USER");

	    // Check if UserType with the given name already exists
	    Table_Usertype savedUserType = usertypeRepository.findByName(usertypeDTO.getName());
	    if (savedUserType != null) {
	        employee.setUserType(savedUserType);
	        
	    } else {
	        // UserType does not exist, so save it and then set it in the employee
	        Table_Usertype userType = new Table_Usertype();
	        userType.setName(usertypeDTO.getName());
	        usertypeRepository.save(userType);
	        employee.setUserType(userType);
	    }

	    employeeRepository.save(employee);
	    return "User Registration Successful.";
	}
	
    /*@Override
	public String employeeRegistration(EmployeeRegisterDto employeeRegisterDto, UsertypeRegisterDto usertypeDTO) {

	    EmployeesInfo employee = new EmployeesInfo();
        
	    employee.setFirstname(employeeRegisterDto.getFirstName());
	    employee.setLastname(employeeRegisterDto.getLastName());
	    employee.setGender(employeeRegisterDto.getGender());
	    employee.setDob(employeeRegisterDto.getDob());
	    employee.setContact(employeeRegisterDto.getContact());
	    employee.setEmail(employeeRegisterDto.getEmail());
	    employee.setPassword(employeeRegisterDto.getPassword());
	    String password = passwordEncoders.encode(employee.getPassword());
	    employee.setPassword(password);
	    employee.setRole("ROLE_USER");

	    // Check if UserType with the given name already exists
	    Table_Usertype savedUserType = usertypeRepository.findByName(usertypeDTO.getName());

	 // Check if the UserType exists in the Table_Usertype table
	 if (savedUserType != null) {
	     // UserType exists, so set it in the employee
	     employee.setUserType(savedUserType);

	     // Retrieve the UserType id
	     int userTypeId = savedUserType.getId();

	     // Get a list of employees with the same UserType id from the EmployeeInfo table
	     List<EmployeesInfo> employees = employeeRepository.findByUserTypeId(userTypeId);
	     LOGGER.info("employees:"+employees);
	     // Set the list of employees in the model attribute for use in the frontend
	     
	 } else {
	     // UserType does not exist, so save it in the Table_Usertype table
	     Table_Usertype userType = new Table_Usertype();
	     userType.setName(usertypeDTO.getName());
	     usertypeRepository.save(userType);

	     // Set the UserType in the employee
	     employee.setUserType(userType);

	     // Retrieve the newly saved UserType id
	     int userTypeId = userType.getId();

	     // Get a list of employees with the same UserType id from the EmployeeInfo table
	     List<EmployeesInfo> employees = employeeRepository.findByUserTypeId(userTypeId);

	     // Set the list of employees in the model attribute for use in the frontend
	     
	 }

	    employeeRepository.save(employee);
	    return "User Registration Successful.";
	}*/
	
	
	@Override
	public List<EmployeesInfo> validateEmployee(String email, String password) {

		
		List<EmployeesInfo> Employees =employeeRepository.findByEmailAndPassword(email,  password);

		return Employees;
		
}
		@Override
		public void updateEmployee(EmployeesInfo employee) {
			
			employeeRepository.save(employee);
			  
			
		}
		@Transactional
		
	    public void deleteById( int id) {
			employeeRepository.deleteById(id);
	    }
		@Override
		public boolean isEmailUnique(String email) {
			
			return !employeeRepository.existsByEmail(email);
		}
		
		@Override
		public EmployeesInfo findByEmail(String email) {
			
			return employeeRepository.findByEmail(email);
		}
		@Override
		public EmployeesInfo getEmployeeByEmail(String email) {
			
			return employeeRepository.getEmployeeByEmail(email);
		}

		@Override
		public int getUserTypeByUsername(String loggedInUsername) {
			
			 return employeeRepository.findUserTypeByUsername(loggedInUsername);
		}

		@Override
		public List<EmployeesInfo> findEmployeesByUserType(int userType) {
			
			return employeeRepository.findEmployeesByUserType(userType);
		}

		
		
		@Override
		public List<EmployeesInfo> getEmployeesByUserType(int userType) {
			
			return employeeRepository.getEmployeesByUserType(userType);
		}

		@Override
		public int getUserTypeById(String passingName) {
			
			return employeeRepository.getUserTypeById(passingName);
		}

		
		
}

			
