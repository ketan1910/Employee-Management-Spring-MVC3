package com.Employee.Repo;


import org.springframework.data.jpa.repository.JpaRepository;

import com.Employee.Entity.Table_Usertype;

public interface UsertypeRepository extends JpaRepository<Table_Usertype, String> {

	
	
	Table_Usertype findByName(String name);

	
}
