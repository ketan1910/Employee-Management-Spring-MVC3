package com.Employee.Repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.Employee.Entity.EmployeesInfo;
import com.Employee.Entity.Table_Usertype;
@Repository
public interface EmployeeRepository extends JpaRepository<EmployeesInfo, Integer>{

	List<EmployeesInfo> findByEmailAndPassword(String email, String password);
	
	
	EmployeesInfo findById(int id);
	
	
	
	@Modifying
	@Query(value = "DELETE FROM employees_Info WHERE id = ?1", nativeQuery = true)
	
	void deleteById(int id);
	
	 List<EmployeesInfo> findEmployeeByEmail(String email);
	 
	 boolean existsByEmail(String email);

	 EmployeesInfo findByEmail(@Param("email") String email);

     EmployeesInfo getEmployeeByEmail(@Param("email") String email);


	int getUserTypeByEmail(String email);
 
	//For View
	
	@Query(value = "SELECT * FROM employees_Info WHERE usertype = :userType", nativeQuery = true)
	List<EmployeesInfo> findEmployeesByUserType(int userType);
//
	@Query(value = "SELECT usertype FROM employees_Info WHERE email = :loggedInUsername", nativeQuery = true)
	int findUserTypeByUsername(String loggedInUsername);

	//For Register
	
	
	@Query(value = "SELECT * FROM employees_Info WHERE usertype = :userType" , nativeQuery = true)
    List<EmployeesInfo> getEmployeesByUserType(int userType);

	@Query(value = "SELECT * FROM employees_Info WHERE usertype = :userType" , nativeQuery = true)
	List<EmployeesInfo> getEmployeesByUserType(Table_Usertype userType);

	@Query(value = "SELECT e.usertype FROM employees_Info as e JOIN Table_usertype as t ON e.usertype = t.id WHERE t.name = :passingName", nativeQuery = true)
	int getUserTypeById(String passingName);

}
	





	
	
	
	

	

	

