package com.Employee.Controller;


import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.Employee.Entity.EmployeesInfo;
import com.Employee.Model.EmployeeRegisterDto;
import com.Employee.Model.UsertypeRegisterDto;
import com.Employee.Service.EmployeeService;
import jakarta.servlet.http.HttpServletRequest;



@Controller
public class registerloginController<UserTypeRequest, NameReaquest, NameRequest> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(registerloginController.class.getName());
	 @Autowired
	 EmployeeService employeeService;
     

	
	 @GetMapping("/register")
	 public String sayHello() {
		
	     return "register";
	 }
	 
	 
	/* @PostMapping("employee/register")
	 public ModelAndView registerEmployee(HttpServletRequest request,HttpServletResponse response, Model model) {
	     ModelAndView modelAndView = new ModelAndView();
	     EmployeeRegisterDto employeeRegisterDto = new EmployeeRegisterDto();
	     UsertypeRegisterDto usertypeDTO = new UsertypeRegisterDto();
	     employeeRegisterDto.setFirstName(request.getParameter("firstname"));
	     employeeRegisterDto.setLastName(request.getParameter("lastname"));
	     employeeRegisterDto.setGender(request.getParameter("gender"));
	     employeeRegisterDto.setDob(request.getParameter("dob"));
	     employeeRegisterDto.setContact(request.getParameter("contact"));
	     employeeRegisterDto.setEmail(request.getParameter("email"));
	     employeeRegisterDto.setPassword(request.getParameter("password"));
	     usertypeDTO.setName(request.getParameter("name"));
	     LOGGER.info("registerEmployee usertypeDTO:" + usertypeDTO);
	     String passingName = usertypeDTO.getName();
	     String email=employeeRegisterDto.getEmail();
	     LOGGER.info("email:" + email);

	     if (passingName != null) {
             int userType = employeeService.getUserTypeById(passingName);
	         List<EmployeesInfo> employees = employeeService.getEmployeesByUserType(userType);	       
	         LOGGER.info("userType:" + userType);
	         LOGGER.info("employees:" + employees);
	         LOGGER.info("passingName:" + passingName);
	         modelAndView.addObject("employees", employees);
	         //model.addAttribute("employees", employees);
	      
	         model.addAttribute("passingName", passingName);
	        
	     }
	     if (!email.isEmpty()) {
	         if (employeeService.isEmailUnique(employeeRegisterDto.getEmail())) {
	             String result = employeeService.employeeRegistration(employeeRegisterDto, usertypeDTO);
	              modelAndView.addObject("message", "Registration Successful...!");
	             modelAndView.addObject("result", result);
	             modelAndView.setViewName("redirect:/login");
	         } else {
	             modelAndView.setViewName("redirect:/register");
	             modelAndView.addObject("error", "Email is already in use. Please choose a different email.");
	         }
	     } else {
	         modelAndView.setViewName("redirect:/register");
	        
	     }
	     return modelAndView;
	 }
	 */
	 
	 @PostMapping("employee/register")
	 public  ModelAndView registerEmployee(HttpServletRequest request,Model model) {
	     ModelAndView modelAndView = new ModelAndView();
         EmployeeRegisterDto employeeRegisterDto = new EmployeeRegisterDto();
         UsertypeRegisterDto usertypeDTO=new UsertypeRegisterDto();
	     employeeRegisterDto.setFirstName(request.getParameter("firstname"));
	     employeeRegisterDto.setLastName(request.getParameter("lastname"));
	     employeeRegisterDto.setGender(request.getParameter("gender"));
	     employeeRegisterDto.setDob(request.getParameter("dob"));
	     employeeRegisterDto.setContact(request.getParameter("contact"));
	     employeeRegisterDto.setEmail(request.getParameter("email"));
	     employeeRegisterDto.setPassword(request.getParameter("password"));
	     usertypeDTO.setName(request.getParameter("name"));
	     LOGGER.info("registerEmployee usertypeDTO:"+usertypeDTO);
	       /*String passingName = usertypeDTO.getName();
    	   if (passingName != null) {
    		 
		     int userType = employeeService.getUserTypeById(passingName);
		     List<EmployeesInfo> employees = employeeService.getEmployeesByUserType(userType);
		     model.addAttribute("employees", employees);
		     LOGGER.info("userType:" + userType);
		     LOGGER.info("employees:" + employees);
		     model.addAttribute("employeeRegisterDto", new EmployeeRegisterDto());
		     model.addAttribute("usertypeDTO", new UsertypeRegisterDto());
		 }*/
	     if (employeeService.isEmailUnique(employeeRegisterDto.getEmail())) {
	    	 
	    	
	    	 /*String passingName = usertypeDTO.getName();
	    	 LOGGER.info("passingName:"+passingName);
	         int userType = employeeService.getUserTypeById(passingName);
	        
	         List<EmployeesInfo> Employees = employeeService.getEmployeesByUserType(userType);
	    	 model.addAttribute("Employees", Employees);
	    	 LOGGER.info("userType:"+userType);
	    	 LOGGER.info("Employees:"+Employees);*/

	         String result = employeeService.employeeRegistration(employeeRegisterDto,usertypeDTO);
	         
	         modelAndView.setViewName("redirect:/login");
	         modelAndView.addObject("message", "Registration Successfull...!");
	         modelAndView.addObject("message", result);
	         
	     } else {
	          
	    	 modelAndView.setViewName("redirect:/register");
	         modelAndView.addObject("error", "Email is already in use. Please choose a different email.");
	         
	     }

	     return  modelAndView;
	 }
	 
	 @GetMapping("/getEmployee")
	 public String getEmployee(@RequestParam ("userType") int userType,Model model){
		 
		 ModelAndView modelAndView = new ModelAndView();
		 List<EmployeesInfo> employees=employeeService.getEmployeesByUserType(userType);
	     modelAndView.setViewName("register");
		 modelAndView.addObject("employees", employees);
		 model.addAttribute("userType", userType);
		 LOGGER.info("userType:"+userType);
    	 LOGGER.info("employees:"+employees);
		return employees.toArray().toString();
		// return "employees";
	 }
	 
	    @GetMapping("/login")
		public ModelAndView loadLoginPage() {
            ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("login");
            return modelAndView;
		}
	 @PostMapping("employee/login")
	 public ModelAndView validateUser(HttpServletRequest request, EmployeesInfo employee) {
		
	     List<EmployeesInfo> Employees = employeeService.validateEmployee(request.getParameter("email"), request.getParameter("password"));
	   
	     ModelAndView modelAndView = new ModelAndView();
	    LOGGER.info("Employees.size:"+Employees.size());
	     if (Employees.size() > 0) {
	    	 
	    	 modelAndView.setViewName("redirect:/user/home");
	         modelAndView.addObject("message", "Your Login Successful!");
	         modelAndView.addObject("Employees", Employees);
	        
	     } else {
	         
	    	 modelAndView.setViewName("redirect:/login");
	         modelAndView.addObject("error", "Invalid Credentials!");
	     }

	     return modelAndView;
	 }
	 
	
	    @GetMapping("/logout")
	    public ModelAndView logout(Model model) {
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("/login");
	        modelAndView.addObject("message", "You Are sucessfully Logout");
	        return modelAndView;
	    }
		
  }

