package com.Employee.Controller;

import java.util.Random;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;



import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.Employee.Entity.EmployeesInfo;

import com.Employee.Service.EmailService;
import com.Employee.Service.EmployeeService;


import jakarta.servlet.http.HttpSession;

@Controller
public class ForgotController {
	@Autowired
	private EmployeeService  service;
	
    @Autowired
    private EmailService emailService;
    
    
    
    
    Random random = new Random();
    
    
    @RequestMapping("/Forgot")
	 public String ForgotPassword() {
     //EmployeesInfo employee =service.findByEmail(email);
     
	  return "Forgot_Email_Form";
	}
    
    @PostMapping("/sendOTP")
    public String sendOTP(@RequestParam("email") String email,HttpSession session) {
        // Assuming you have a service class to retrieve employee info by email
       EmployeesInfo employee =service.findByEmail(email);
    	
        System.out.println("email:" + email);
        if (employee != null) {
           // Get the email address from the fetched employee
            System.out.println("email:" + email);
            // Generate OTP
            int otp = generateOTP();

            // Send OTP via email
            String subject = "OTP for Password Reset";
            String message = "Your OTP is: " + otp;
            String to = employee.getEmail(); 
            
            System.out.println("Retrieved email from Employee object: " + employee.getEmail());
            System.out.println("OTP:" + otp);
            boolean emailSent = emailService.sendEmail(to, subject, message);
            System.out.println("to:" + to);
            if (emailSent) {
                // If email sent successfully, proceed to OTP verification page
            	session.setAttribute("myotp",otp);
            	session.setAttribute("email",email);
                return "redirect:verifyOtp=" + to;
            } else {
                // If email sending failed, return to the forgot password form with an error message
                return "redirect:forgot_Email_Form=Failed to send OTP. Please try again.";
            }
        }
        // If employee not found, handle the error accordingly
        session.setAttribute("message","Enter valid Email");
        return "redirect:/register=Employee not found.";
    }

    private int generateOTP() {
        // Generate a random 4-digit OTP
        return 1000 + random.nextInt(9000);
    }
}

    


