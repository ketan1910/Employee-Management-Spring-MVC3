package com.Employee.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import java.security.Principal;
import java.util.List;
import com.Employee.Entity.EmployeesInfo;
import com.Employee.Service.EmployeeService;


@Controller
public class EmployeeController {
	
	
	@Autowired
	EmployeeService service;
	

	@GetMapping("/user/home")
    public String home(Model model) {
        model.addAttribute("message", "Welcome to Home");
        
        return "home";
    }
	
	@GetMapping("/user/viewEmployees")
    public String viewEmployees(Model model, Principal principal) {
        String loggedInUsername = principal.getName();
        int userType = service.getUserTypeByUsername(loggedInUsername);
        List<EmployeesInfo> employees = service.findEmployeesByUserType(userType);
        model.addAttribute("employees", employees);
        model.addAttribute("userType", userType);
        return "views";
    }
	
	    @GetMapping("/user/add")
        public String NewEmployee(Model model) {
		model.addAttribute("employee", new EmployeesInfo());
        return "add";
    }
	
	
	@PostMapping("/user/addEmployee")
    public String addEmployee(@ModelAttribute("employee") EmployeesInfo employee) {
		service.addEmployee(employee);
		
	    
         return "redirect:/user/viewEmployees";
    }
	

	@GetMapping("/user/edit/{id}")
	public String EditForm(@PathVariable int id, Model model) {
	    EmployeesInfo employee =service.getEmployeeById(id);
	    System.out.println("employee:"+employee);
	    model.addAttribute("id", id);
	    model.addAttribute("employee", employee);
	    return "edit";
	}
	
	
	@PostMapping("/user/edit/{id}")
    public ModelAndView editEmployee(@PathVariable int id, Model model,@ModelAttribute EmployeesInfo employee) {
	service.updateEmployee( employee,id);
	 ModelAndView modelAndView = new ModelAndView();
	model.addAttribute("id", id);
	model.addAttribute("employee",employee);
	modelAndView.setViewName("redirect:/user/viewEmployees");
	modelAndView.addObject("message", "Employee Details Are Updated....!");
	return modelAndView;
	}
	

	@GetMapping("/user/delete/{id}")
    public String deleteById(@PathVariable int id,Model model,@ModelAttribute("employee") EmployeesInfo employee) {
		service.deleteById(id);	
		model.addAttribute("id", id);
	    model.addAttribute("employee", employee);
        return "redirect:/user/viewEmployees";
    }
	
    }
	
	


