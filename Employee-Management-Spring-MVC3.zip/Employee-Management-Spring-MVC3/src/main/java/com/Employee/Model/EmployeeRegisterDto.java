package com.Employee.Model;

public class EmployeeRegisterDto {

	private String firstname;
	private String lastname;
	private String gender;
	private String email;
    private String dob;
	private String contact;
	private String password;
	public int usertype;
	
	
	public void setContact(String contact) {
		this.contact=contact;
	}

	public void setFirstName(String firstname) {
		this.firstname=firstname;
	}

	public void setLastName(String lastname) {
		this.lastname=lastname;
		
	}

	public void setGender(String gender) {
		this.gender=gender;
		
	}

	public void setDob(String dob) {
		this.dob=dob;
		
	}

	public void setEmail(String email) {
		this.email=email;
		
	}

	public void setPassword(String password) {
		this.password=password;
		
	}
	
   

public String getContact() {
		
		return contact;
	}

	public String getFirstName() {
		
		return firstname;
	}

	public String getLastName() {
		
		return lastname;
	}

	public String getGender() {
		
		return gender;
	}

	public String getDob() {
		
		return dob;
	}

	public String getEmail() {
		
		return email;
	}

	public String getPassword() {
		
		return password;
	}

	public int getUsertype() {
		return usertype;
	}

	public void setUsertype(int usertype) {
		this.usertype = usertype;
	}

	}