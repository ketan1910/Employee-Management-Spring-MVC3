package com.Employee.Model;

public class UsertypeRegisterDto {
public int id;
public String name;
int getId() {
	return id;
}
void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public String toString() {
	return "UsertypeRegisterDto [id=" + id + ", name=" + name + "]";
}

}
