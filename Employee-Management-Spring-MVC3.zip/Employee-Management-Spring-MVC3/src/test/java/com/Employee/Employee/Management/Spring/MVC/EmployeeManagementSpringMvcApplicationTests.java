package com.Employee.Employee.Management.Spring.MVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSpringMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
